package com.example.ammad_shaikh

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
